/* ==========================================================================
   SCRIPT.JS – det som gör sidan "levande"
   --------------------------------------------------------------------------
   HTML-filerna innehåller texten, style.css bestämmer utseendet, och den
   här filen gör att saker HÄNDER när man klickar, trycker eller scrollar.

   Filen gör tre saker:
     1. Öppnar och stänger "Meny"-knappen på mobilen.
     2. Kopierar texten i formuläret på kontaktsidan.
     3. Tonar fram text och bilder när man scrollar ner till dem.

   Rader som börjar med // är kommentarer. Datorn hoppar över dem –
   de finns bara för att förklara för människor.
   ========================================================================== */


// Talar om för style.css att det här skriptet faktiskt har startat
// (sätter etiketten "js" på hela sidan). Då vet style.css att det är
// säkert att gömma saker som ska tona fram senare. Om skriptet INTE
// startar visas allt som vanligt istället.
document.documentElement.classList.add('js');


/* --------------------------------------------------------------------------
   1. MOBILMENYN
   -------------------------------------------------------------------------- */

// Letar upp "Meny"-knappen på sidan och sparar den under namnet "toggle".
const toggle = document.querySelector('.menu-toggle');

// Letar upp själva menyn (länkarna Hem, Tjänster osv.) och sparar den
// under namnet "navigation".
const navigation = document.querySelector('#navigation');

// En liten instruktion (funktion) som heter closeMenu och stänger menyn.
function closeMenu() {
  // Talar om för skärmläsare (hjälpmedel för synskadade) att menyn är stängd.
  toggle.setAttribute('aria-expanded', 'false');
  // Tar bort etiketten "open" från menyn, så att style.css gömmer den.
  navigation.classList.remove('open');
}

// Säger: "När någon klickar på Meny-knappen, gör följande:"
toggle.addEventListener('click', () => {
  // Kollar om menyn är stängd just nu. Är den stängd ska den öppnas,
  // är den öppen ska den stängas. Svaret sparas i "open" (sant/falskt).
  const open = toggle.getAttribute('aria-expanded') !== 'true';
  // Talar om för skärmläsare om menyn nu är öppen eller stängd.
  toggle.setAttribute('aria-expanded', String(open));
  // Sätter på eller tar bort etiketten "open" på menyn,
  // så att style.css visar eller gömmer den.
  navigation.classList.toggle('open', open);
});

// Säger: "När någon trycker på Esc-tangenten på tangentbordet,
// stäng menyn."
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });


/* --------------------------------------------------------------------------
   2. FORMULÄRET PÅ KONTAKTSIDAN
   Formuläret skickar INGENTING någonstans. Det kopierar bara texten
   man skrivit, så att man själv kan klistra in den i ett sms eller mejl.
   -------------------------------------------------------------------------- */

// Letar upp formuläret. Det finns bara på kontaktsidan – på andra sidor
// hittas inget, och då hoppas hela den här delen över.
const form = document.querySelector('#project-form');

// "Om formuläret finns på den här sidan…"
if (form) {
  // "…så, när någon trycker på knappen 'Kopiera beskrivningen', gör följande:"
  form.addEventListener('submit', async event => {
    // Stoppar webbläsarens vanliga beteende (att ladda om sidan
    // och försöka skicka formuläret).
    event.preventDefault();

    // Letar upp textrutan där man skriver sitt meddelande.
    const message = document.querySelector('#message');
    // Letar upp den tomma raden där vi visar ett meddelande till besökaren.
    const status = document.querySelector('#form-status');

    // Om textrutan är tom (eller bara innehåller mellanslag)…
    if (!message.value.trim()) {
      // …visa en uppmaning att skriva något först,
      status.textContent = 'Skriv en kort beskrivning först.';
      // flytta markören till textrutan,
      message.focus();
      // och sluta här (gör inget mer).
      return;
    }

    // Bygger ihop texten som ska kopieras: först det man valt i
    // rullgardinsmenyn ("Vad gäller det?"), sedan en tom rad, sedan
    // det man skrivit i textrutan.
    const text = `${document.querySelector('#topic').value}\n\n${message.value.trim()}`;

    // "Försök" att kopiera texten automatiskt…
    try {
      // Lägger texten i datorns/mobilens urklipp (samma som Ctrl+C).
      await navigator.clipboard.writeText(text);
      // Om det gick bra: visa ett bekräftelsemeddelande.
      status.textContent = 'Kopierat! Klistra in beskrivningen i ett sms eller mejl.';
    } catch {
      // …men om det INTE gick (vissa webbläsare tillåter inte det):
      // flytta markören till textrutan,
      message.focus();
      // markera all text där, så att besökaren lätt kan kopiera själv,
      message.select();
      // och förklara vad som hände.
      status.textContent = 'Automatisk kopiering är inte tillgänglig. Texten är markerad – kopiera den själv.';
    }
  });
}


/* --------------------------------------------------------------------------
   3. TONA FRAM SAKER NÄR MAN SCROLLAR
   Allt på sidan med class="reveal" börjar osynligt (se style.css).
   När man scrollar så att det syns på skärmen tonar det fram.
   -------------------------------------------------------------------------- */

// Letar upp ALLA saker på sidan som har etiketten "reveal".
const revealItems = document.querySelectorAll('.reveal');

// Kollar om webbläsaren har funktionen som kan "se" när något kommer
// in på skärmen (IntersectionObserver). Nästan alla moderna har det.
if ('IntersectionObserver' in window) {
  // Skapar en "observatör" – en vakt som håller koll på sakerna.
  const observer = new IntersectionObserver(entries => {
    // Varje gång något ändras går vakten igenom sakerna en och en:
    entries.forEach(entry => {
      // Om saken nu syns på skärmen…
      if (entry.isIntersecting) {
        // …ge den etiketten "visible", så att style.css tonar fram den,
        entry.target.classList.add('visible');
        // och sluta bevaka den (den ska bara tona fram en gång).
        observer.unobserve(entry.target);
      }
    });
  // 0.15 betyder: reagera när 15 % av saken syns på skärmen.
  }, { threshold: 0.15 });

  // Ber vakten att börja hålla koll på varje "reveal"-sak.
  revealItems.forEach(item => observer.observe(item));
} else {
  // Om webbläsaren är för gammal för att ha vakten:
  // visa allt direkt istället, så att inget förblir osynligt.
  revealItems.forEach(item => item.classList.add('visible'));
}
